package com.example.capturaacelerometro;

public class emergencia {

}
